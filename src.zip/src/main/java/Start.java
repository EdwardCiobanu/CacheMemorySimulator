import presentation.CacheView;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Start {

    public static void main(String[] args) {
        CacheView cacheView = new CacheView();
//        System.out.println("heloo worlds");
    }
}
